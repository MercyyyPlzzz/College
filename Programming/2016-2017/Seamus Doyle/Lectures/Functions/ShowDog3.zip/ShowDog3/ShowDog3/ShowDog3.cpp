// ShowDog3.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
using namespace std;
//Function Prototypes
void LoadDog(ifstream& infile, int dog[12][10]);
void Delay(void);
void ShowDog(int dog[12][10], int position);

int _tmain(int argc, _TCHAR* argv[])
{
          int dog[12][10];
          ifstream infile("Dog.txt");
          LoadDog(infile, dog);
         		 
		 ShowDog(dog,0);
		 Delay();
		 ShowDog(dog, 2);
		 Delay();
		 ShowDog(dog, 6);
		 		 
		 cin.get();
         return 0;
}
 

 void LoadDog(ifstream& infile, int dog[12][10])
 {
		  //load image
          for (int row = 0; row < 12; row++)
          {
                   for (int col = 0; col < 10; col++)
                   {
                             infile >> dog[row][col];
                   }
          }

 }

void Delay(void)
{
		 //generate a delay and clear the screen
          int j = 0;
          for ( int i = 0; i < 100000000; i++)
          {
                   j++;
          }
          system("cls");
}

void ShowDog(int dog[12][10], int position)
{
		 //display the image in position
          for (int row = 0; row < 12; row++)
          {
                  for ( int i = 0; i < position; i++ ) 
						cout << "\t\t";
                   for (int col = 0; col < 10; col++)
                   {
                             if ( dog[row][col] == 0 )
                                      cout << (char)0x00;
                             else
                                      cout << (char)0xDB;
                   }
                   cout << endl;
          }        

}



