// Practical4.cpp : Defines the entry point for the console application.
// Practical 4 K00220137 - Mckinley Magale

#include "stdafx.h"
#include "Stack.h"
#include "Queue.cpp"

using namespace std;
int _tmain(int argc, _TCHAR* argv[])
{
	cout << "\t\tQueues & Stacks";
	cout << "\n\t1.\tClear Queue";
	cout << "\n\t2.\tAdd Data";
	cout<<"\n\t3. "
    return 0;
}

