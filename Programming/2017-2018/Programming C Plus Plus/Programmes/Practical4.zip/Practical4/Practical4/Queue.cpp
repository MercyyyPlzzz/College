#include <stddef.h> //FOR NULL
template <class ItemType>
struct NodeType
{
	ItemType info;
	NodeType* next;
};

template <class ItemType>
QueType<ItemType>::QueType()
{
	qFront = NULL;
	qRear = NULL;
}

template <class ItemType>
QueType<ItemType>::~QueType()
{
	MakeEmpty();
}

template <class ItemType>
void QueType<ItemType>::MakeEmpty()
{
	NodeType<ItemType>* tempPtr;
	while (qFront != NULL)
	{
		tempPtr = qFront;
		qFront = qFront->next;
		delete tempPtr;
	}
	qRear = NULL;
}

template <class ItemType>
bool QueType<ItemType>::IsFull() const
{
	NodeType<ItemType>* ptr;
	ptr = new NodeType<ItemType>;
	if (ptr == NULL)
		return true;
	else 
	{
		delete ptr;
		return false;
	}
}

template <class ItemType>
bool QueType<ItemType>::IsEmpty() const
{
	return (qFront == NULL);
}

template <class ItemType>
void QueType<ItemType>::Enqueue(ItemType newItem)
{
	NodeType<ItemType>* newNode;
	newNode = new NodeType<ItemType>;
	newNode->info = newItem;
	newNode->next = NULL;
	if (qRear == NULL)
		qFront = newNode;
	else
		qRear->next = newNode;
	qRear = newNode;
}

template <class ItemType>
void QueType<ItemType>::Dequeue(ItemType& item)
{
	NodeType<ItemType>* tempPtr;
	tempPtr = qFront;
	item = qFront->next;
	if (qFront == NULL)
		qRear = NULL;
	delete tempPtr;
}