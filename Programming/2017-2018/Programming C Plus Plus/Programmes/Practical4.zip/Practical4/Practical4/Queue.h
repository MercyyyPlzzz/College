#pragma once
template <class ItemType>
struct NodeType;