#pragma once
template <class ItemType>
struct NodeType;

template<class ItemType>
class StackType
{
public:
	StackType();
	~StackType();
	void MakeEmpty();
	bool IsFull() const;
	bool IsEmpty() const;
	void Push(ItemType item);
	void Pop(ItemType& item);
	void PrintStack();
private:
	NodeType<ItemType>* topPtr;
};

template <class ItemType>
struct NodeType
{
	ItemType info;
	NodeType<ItemType>* next;
};

template<class ItemType>
StackType<ItemType>::StackType()
{
	topPtr = NULL;
}

template <class ItemType>
StackType<ItemType>::~StackType()
{
	NodeType<ItemType>* tempPtr;
	while (topPtr != NULL)
	{
		tempPtr = topPtr;
		topPtr = topPtr->next;
		delete tempPtr;
	}
}

template<class ItemType>
void StackType<ItemType>::Pop(ItemType& item)
{
	NodeType<ItemType>* tempPtr;
	item = topPtr->info;
	tempPtr = topPtr;
	topPtr = topPtr->next;
	delete tempPtr;
}

template <class ItemType>
void StackType<ItemType>::Push(ItemType newItem)
{
	NodeType<ItemType>* location;
	location = new NodeType<ItemType>;
	location->info = newItem;
	location->next = topPtr;
	topPtr = location;
}

template<class ItemType>
bool StackType<ItemType>::IsFull() const
{
	NodeType<ItemType>* ptr;
	ptr = new NodeType<ItemType>;
	if (ptr == NULL)
		return true;
	else
	{
		delete ptr;
		return false;
	}
}

template <class ItemType>
bool StackType<ItemType>::IsEmpty() const
{
	return (topPtr == NULL);
}


template <class ItemType>
void StackType<ItemType>::MakeEmpty()
{
	NodeType<ItemType>* tempPtr;

	while (topPtr != NULL)
	{
		tempPtr = topPtr;
		topPtr = topPtr->next;
		delete tempPtr;
	}
}

template <class ItemType>
void StackType<ItemType>::PrintStack()
{
	NodeType<ItemType>* tempPtr;
	tempPtr = topPtr;
	while (tempPtr != NULL)
	{
		cout << tempPtr->info << endl;
		tempPtr = tempPtr->next;
	}

}