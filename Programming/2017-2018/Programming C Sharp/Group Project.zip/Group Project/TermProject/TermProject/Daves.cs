﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TermProject
{
    public class Daves
    {
        public string name { get; set; }
        public string DOB { get; set; }
        public string details { get; set; }
        public int birth { get; set; }
        public int age { get; set; }
        public int twins { get; set; }
    }
}
