﻿namespace TermProject
{
    partial class frmListAge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvListAge = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // lvListAge
            // 
            this.lvListAge.Location = new System.Drawing.Point(13, 13);
            this.lvListAge.Margin = new System.Windows.Forms.Padding(4);
            this.lvListAge.Name = "lvListAge";
            this.lvListAge.Size = new System.Drawing.Size(391, 433);
            this.lvListAge.TabIndex = 2;
            this.lvListAge.UseCompatibleStateImageBehavior = false;
            // 
            // frmListAge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 463);
            this.Controls.Add(this.lvListAge);
            this.Name = "frmListAge";
            this.Text = "frmListAge";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvListAge;
    }
}