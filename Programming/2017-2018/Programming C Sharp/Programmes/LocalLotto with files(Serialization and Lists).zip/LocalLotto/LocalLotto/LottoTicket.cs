﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocalLotto
{
    [Serializable]
    class LottoTicket
    {
        

       public int ticketNumber  { get; set; }
        public SortedSet<int> numbers { get; set; }


        public LottoTicket(int i, SortedSet<int> num)
        {
            
            this.ticketNumber = i;
            this.numbers = num;
        }

        public void print(){
            Console.WriteLine("***********************************");
            Console.Write("id: " + ticketNumber + " ");
            Console.Write("Numbers : ");
            foreach(int i in numbers){
                Console.Write(i + " ");

            }
            Console.WriteLine();
            Console.WriteLine("***********************************");
        }
    }
}
