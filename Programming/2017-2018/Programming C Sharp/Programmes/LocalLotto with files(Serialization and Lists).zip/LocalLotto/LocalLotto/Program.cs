﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace LocalLotto
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList to hold data - an array list of lotto tickets
            List<LottoTicket> lotto = new List<LottoTicket>();
            SortedSet<int> WinningNumbers = new SortedSet<int>();
            string curFile = "lotto3.dat";

            
            
            int option;

            do
            {
                Console.WriteLine(" *** local Lotto **** ");
                Console.WriteLine("Option 1: Generate Text Data");
                Console.WriteLine("Option 2: Display Data");
                Console.WriteLine("Option 3: Draw");
                Console.WriteLine("Option 4: Find Winner");
                Console.WriteLine("Option 5: Find Match 3 or more");
                Console.WriteLine("Option 6: Write data to file");
                Console.WriteLine("Option 7: Read data from file");
                Console.WriteLine("Option 8: Exit");

                Console.WriteLine("");
                Console.WriteLine("Enter Option:");

                string stringOption = Console.ReadLine();
                option = Int32.Parse(stringOption);

                switch (option)
                {
                    case 1:
                        {
                            setUpData(lotto);
                            break;
                        }
                    case 2:
                        {
                            display(lotto);
                            break;
                        }
                    case 3:
                        {
                            draw(WinningNumbers);
                            break;
                        }
                    case 4:
                        {
                            findMatch(lotto, WinningNumbers, 6);
                            break;
                        }

                    case 5:
                        {
                            findMatch(lotto, WinningNumbers, 3);
                            break;
                        }
                    case 6:
                        {
                            writeDataToFile(lotto, curFile);
                            break;
                        }
                    case 7:
                        {
                            ReadDatafromFile(ref lotto, curFile);
                            break;
                        }
                }
            } while (option != 8);
        }
        public static void ReadDatafromFile(ref List<LottoTicket> l, string curFile)
        {

            List<LottoTicket> temp = new List<LottoTicket>();
            
            FileInfo fInfo = new FileInfo(curFile);
            FileStream lottoFile;
            
            if (fInfo.Exists)
            {
                lottoFile = new FileStream(curFile, FileMode.Open, FileAccess.Read);
                Console.WriteLine("found file for read " + fInfo.FullName);
                BinaryFormatter bformatter = new BinaryFormatter();
                try
                {
                    temp = bformatter.Deserialize(lottoFile) as List<LottoTicket>;
                    l = temp;
                 
                }catch (Exception e)
                {
                    Console.WriteLine("{0} Exception caught.", e);
                 }
                lottoFile.Close();
            }
            else
            {
                Console.WriteLine("ERROR CANT FIND FILE " + fInfo.FullName);
            }
          
            Console.WriteLine("data read");
        }

        public static void writeDataToFile(List<LottoTicket> l, string curFile)
        {

                FileInfo fInfo = new FileInfo(curFile);
                FileStream lottoFile;
              
                if (fInfo.Exists)
                {
                    lottoFile = new FileStream(curFile, FileMode.Truncate, FileAccess.Write);
                    Console.WriteLine("found file " + fInfo.FullName);
                }
                else
                {
                    lottoFile = new FileStream(curFile, FileMode.Create, FileAccess.Write);
                    Console.WriteLine("created file " + fInfo.FullName);
                }
              
                BinaryFormatter bformatter = new BinaryFormatter();
                
                try
                {   
                    bformatter.Serialize(lottoFile, l);
                   
                  
                }
                catch (Exception e)
                {
                    Console.WriteLine("{0} Exception caught.", e);
                }

                lottoFile.Close();

                Console.WriteLine("data written to file");


        }

        public static void findMatch(List<LottoTicket> l, SortedSet<int> wn, int noOfnumbers)
        {
            int countMatches = 0;
            foreach (LottoTicket t in l)
            {

                SortedSet<int> tnums = new SortedSet<int>(t.numbers);

                tnums.IntersectWith(wn);
                if (tnums.Count >= noOfnumbers)
                {
                    Console.WriteLine("match {0}  ", tnums.Count);
                    t.print();
                    countMatches++;
                }

            }
            Console.WriteLine("There are {0} number of match {1}", countMatches, noOfnumbers);



        }
        public static void draw(SortedSet<int> wn)
        {

            Console.WriteLine("enter winning numbers");
            do
            {
                Console.WriteLine("Enter Number");
                wn.Add(Convert.ToInt32(Console.ReadLine()));
            } while (wn.Count < 6);

        }
        public static void setUpData(List<LottoTicket> l)
        {
            Random rnd = new Random();
            int startAt = l.Count + 1;
            for (int i = startAt; i <= startAt + 1000; i++)
            {
                //generate numbers 6 between 1 - 42
                SortedSet<int> num = new SortedSet<int>();
                do
                {
                    //generate random number
                    int n = rnd.Next(1, 42);

                    //add to set
                    num.Add(n);

                } while (num.Count < 6);
                LottoTicket lt = new LottoTicket(i, num);
                l.Add(lt);

            }
        }

        public static void display(List<LottoTicket> l)
        {   

            foreach (LottoTicket ticket in l)
            {
                ticket.print();
            }

            Console.WriteLine("number of tickets" + l.Count);
        }
    }
}
