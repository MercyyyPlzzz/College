﻿namespace RevisionLab6_calc_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bOne = new System.Windows.Forms.Button();
            this.bTwo = new System.Windows.Forms.Button();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.bThree = new System.Windows.Forms.Button();
            this.bZero = new System.Windows.Forms.Button();
            this.bClearEntry = new System.Windows.Forms.Button();
            this.bFour = new System.Windows.Forms.Button();
            this.bEight = new System.Windows.Forms.Button();
            this.bSeven = new System.Windows.Forms.Button();
            this.bSix = new System.Windows.Forms.Button();
            this.bFive = new System.Windows.Forms.Button();
            this.bNine = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.bDivide = new System.Windows.Forms.Button();
            this.bMinus = new System.Windows.Forms.Button();
            this.bMultiply = new System.Windows.Forms.Button();
            this.bAdd = new System.Windows.Forms.Button();
            this.bEquals = new System.Windows.Forms.Button();
            this.bDecimal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bOne
            // 
            this.bOne.Location = new System.Drawing.Point(10, 106);
            this.bOne.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bOne.Name = "bOne";
            this.bOne.Size = new System.Drawing.Size(40, 32);
            this.bOne.TabIndex = 0;
            this.bOne.Text = "1";
            this.bOne.UseVisualStyleBackColor = true;
            this.bOne.Click += new System.EventHandler(this.bOne_Click);
            // 
            // bTwo
            // 
            this.bTwo.Location = new System.Drawing.Point(55, 106);
            this.bTwo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bTwo.Name = "bTwo";
            this.bTwo.Size = new System.Drawing.Size(40, 32);
            this.bTwo.TabIndex = 1;
            this.bTwo.Text = "2";
            this.bTwo.UseVisualStyleBackColor = true;
            this.bTwo.Click += new System.EventHandler(this.bTwo_Click);
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(10, 11);
            this.txtAnswer.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(218, 20);
            this.txtAnswer.TabIndex = 2;
            // 
            // bThree
            // 
            this.bThree.Location = new System.Drawing.Point(100, 106);
            this.bThree.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bThree.Name = "bThree";
            this.bThree.Size = new System.Drawing.Size(40, 32);
            this.bThree.TabIndex = 3;
            this.bThree.Text = "3";
            this.bThree.UseVisualStyleBackColor = true;
            this.bThree.Click += new System.EventHandler(this.bThree_Click);
            // 
            // bZero
            // 
            this.bZero.Location = new System.Drawing.Point(10, 143);
            this.bZero.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bZero.Name = "bZero";
            this.bZero.Size = new System.Drawing.Size(83, 32);
            this.bZero.TabIndex = 4;
            this.bZero.Text = "0";
            this.bZero.UseVisualStyleBackColor = true;
            this.bZero.Click += new System.EventHandler(this.bZero_Click);
            // 
            // bClearEntry
            // 
            this.bClearEntry.Location = new System.Drawing.Point(142, 33);
            this.bClearEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bClearEntry.Name = "bClearEntry";
            this.bClearEntry.Size = new System.Drawing.Size(40, 32);
            this.bClearEntry.TabIndex = 5;
            this.bClearEntry.Text = "CE";
            this.bClearEntry.UseVisualStyleBackColor = true;
            this.bClearEntry.Click += new System.EventHandler(this.bClearEntry_Click);
            // 
            // bFour
            // 
            this.bFour.Location = new System.Drawing.Point(10, 70);
            this.bFour.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bFour.Name = "bFour";
            this.bFour.Size = new System.Drawing.Size(40, 32);
            this.bFour.TabIndex = 6;
            this.bFour.Text = "4";
            this.bFour.UseVisualStyleBackColor = true;
            this.bFour.Click += new System.EventHandler(this.bFour_Click);
            // 
            // bEight
            // 
            this.bEight.Location = new System.Drawing.Point(54, 33);
            this.bEight.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bEight.Name = "bEight";
            this.bEight.Size = new System.Drawing.Size(40, 32);
            this.bEight.TabIndex = 7;
            this.bEight.Text = "8";
            this.bEight.UseVisualStyleBackColor = true;
            this.bEight.Click += new System.EventHandler(this.bEight_Click);
            // 
            // bSeven
            // 
            this.bSeven.Location = new System.Drawing.Point(10, 33);
            this.bSeven.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bSeven.Name = "bSeven";
            this.bSeven.Size = new System.Drawing.Size(40, 32);
            this.bSeven.TabIndex = 8;
            this.bSeven.Text = "7";
            this.bSeven.UseVisualStyleBackColor = true;
            this.bSeven.Click += new System.EventHandler(this.bSeven_Click);
            // 
            // bSix
            // 
            this.bSix.Location = new System.Drawing.Point(99, 70);
            this.bSix.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bSix.Name = "bSix";
            this.bSix.Size = new System.Drawing.Size(40, 32);
            this.bSix.TabIndex = 9;
            this.bSix.Text = "6";
            this.bSix.UseVisualStyleBackColor = true;
            this.bSix.Click += new System.EventHandler(this.bSix_Click);
            // 
            // bFive
            // 
            this.bFive.Location = new System.Drawing.Point(55, 70);
            this.bFive.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bFive.Name = "bFive";
            this.bFive.Size = new System.Drawing.Size(40, 32);
            this.bFive.TabIndex = 10;
            this.bFive.Text = "5";
            this.bFive.UseVisualStyleBackColor = true;
            this.bFive.Click += new System.EventHandler(this.bFive_Click);
            // 
            // bNine
            // 
            this.bNine.Location = new System.Drawing.Point(98, 33);
            this.bNine.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bNine.Name = "bNine";
            this.bNine.Size = new System.Drawing.Size(40, 32);
            this.bNine.TabIndex = 11;
            this.bNine.Text = "9";
            this.bNine.UseVisualStyleBackColor = true;
            this.bNine.Click += new System.EventHandler(this.bNine_Click);
            // 
            // bClear
            // 
            this.bClear.Location = new System.Drawing.Point(187, 33);
            this.bClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(40, 32);
            this.bClear.TabIndex = 12;
            this.bClear.Text = "C";
            this.bClear.UseVisualStyleBackColor = true;
            this.bClear.Click += new System.EventHandler(this.bClear_Click);
            // 
            // bDivide
            // 
            this.bDivide.Location = new System.Drawing.Point(187, 106);
            this.bDivide.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bDivide.Name = "bDivide";
            this.bDivide.Size = new System.Drawing.Size(40, 32);
            this.bDivide.TabIndex = 13;
            this.bDivide.Text = "÷\r\n";
            this.bDivide.UseVisualStyleBackColor = true;
            this.bDivide.Click += new System.EventHandler(this.bDivide_Click);
            // 
            // bMinus
            // 
            this.bMinus.Location = new System.Drawing.Point(142, 106);
            this.bMinus.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bMinus.Name = "bMinus";
            this.bMinus.Size = new System.Drawing.Size(40, 32);
            this.bMinus.TabIndex = 14;
            this.bMinus.Text = "-";
            this.bMinus.UseVisualStyleBackColor = true;
            this.bMinus.Click += new System.EventHandler(this.bMinus_Click);
            // 
            // bMultiply
            // 
            this.bMultiply.Location = new System.Drawing.Point(187, 70);
            this.bMultiply.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bMultiply.Name = "bMultiply";
            this.bMultiply.Size = new System.Drawing.Size(40, 32);
            this.bMultiply.TabIndex = 15;
            this.bMultiply.Text = "x";
            this.bMultiply.UseVisualStyleBackColor = true;
            this.bMultiply.Click += new System.EventHandler(this.bMultiply_Click);
            // 
            // bAdd
            // 
            this.bAdd.Location = new System.Drawing.Point(142, 70);
            this.bAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bAdd.Name = "bAdd";
            this.bAdd.Size = new System.Drawing.Size(40, 32);
            this.bAdd.TabIndex = 16;
            this.bAdd.Text = "+";
            this.bAdd.UseVisualStyleBackColor = true;
            this.bAdd.Click += new System.EventHandler(this.bAdd_Click);
            // 
            // bEquals
            // 
            this.bEquals.Location = new System.Drawing.Point(142, 143);
            this.bEquals.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bEquals.Name = "bEquals";
            this.bEquals.Size = new System.Drawing.Size(84, 32);
            this.bEquals.TabIndex = 17;
            this.bEquals.Text = "=";
            this.bEquals.UseVisualStyleBackColor = true;
            this.bEquals.Click += new System.EventHandler(this.bEquals_Click);
            // 
            // bDecimal
            // 
            this.bDecimal.Location = new System.Drawing.Point(100, 143);
            this.bDecimal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bDecimal.Name = "bDecimal";
            this.bDecimal.Size = new System.Drawing.Size(40, 31);
            this.bDecimal.TabIndex = 18;
            this.bDecimal.Text = ".";
            this.bDecimal.UseVisualStyleBackColor = true;
            this.bDecimal.Click += new System.EventHandler(this.bDecimal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(231, 180);
            this.Controls.Add(this.bDecimal);
            this.Controls.Add(this.bEquals);
            this.Controls.Add(this.bAdd);
            this.Controls.Add(this.bMultiply);
            this.Controls.Add(this.bMinus);
            this.Controls.Add(this.bDivide);
            this.Controls.Add(this.bClear);
            this.Controls.Add(this.bNine);
            this.Controls.Add(this.bFive);
            this.Controls.Add(this.bSix);
            this.Controls.Add(this.bSeven);
            this.Controls.Add(this.bEight);
            this.Controls.Add(this.bFour);
            this.Controls.Add(this.bClearEntry);
            this.Controls.Add(this.bZero);
            this.Controls.Add(this.bThree);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.bTwo);
            this.Controls.Add(this.bOne);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bOne;
        private System.Windows.Forms.Button bTwo;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Button bThree;
        private System.Windows.Forms.Button bZero;
        private System.Windows.Forms.Button bClearEntry;
        private System.Windows.Forms.Button bFour;
        private System.Windows.Forms.Button bEight;
        private System.Windows.Forms.Button bSeven;
        private System.Windows.Forms.Button bSix;
        private System.Windows.Forms.Button bFive;
        private System.Windows.Forms.Button bNine;
        private System.Windows.Forms.Button bClear;
        private System.Windows.Forms.Button bDivide;
        private System.Windows.Forms.Button bMinus;
        private System.Windows.Forms.Button bMultiply;
        private System.Windows.Forms.Button bAdd;
        private System.Windows.Forms.Button bEquals;
        private System.Windows.Forms.Button bDecimal;
    }
}

